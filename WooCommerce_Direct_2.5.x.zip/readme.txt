****************************************
Plugin Name: WC Gateway Paymentsense Direct

Description: Paymentsense Direct is a plugin that extends WooCommerce, allowing you to take payments via Paymentsense.
Author: Paymentsense
Author URI: http://www.paymentsense.co.uk/
****************************************

What Is Direct Integration:

This allows the merchant to take payments within their own shopping cart solution instead of
redirecting the customer to Paymentsense Servers in order to process the payment. This is
the preferred Integration method for many developers as this method offers the most
flexibility for taking payments and displaying the result to the customer.

